## What it does

Provides other ways to automatically set "vessel type" of a newly launched vessel, other than the default KSP technique of looking what parts are on it.

 
## How to install

Unzip the contents of "GameData" to your GameData folder, same as with most mods.
